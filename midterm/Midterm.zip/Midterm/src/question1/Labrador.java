package question1;

public class Labrador extends Dog{
    @Override
    public double getAverageWeight() {
        return 70.0;
    }
}
