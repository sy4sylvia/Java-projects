package question1;

public class Chihuahua extends Dog{
    @Override
    public double getAverageWeight() {
        return 4.0;
    }
}
