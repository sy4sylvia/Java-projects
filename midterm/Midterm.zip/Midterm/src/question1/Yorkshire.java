package question1;

public class Yorkshire extends Dog{
    @Override
    public double getAverageWeight() {
        return 5.0;
    }
}
