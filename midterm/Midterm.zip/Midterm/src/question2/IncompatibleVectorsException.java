package question2;

public class IncompatibleVectorsException extends Exception{
    // No-Arg Constructor
    public IncompatibleVectorsException() {}

    public IncompatibleVectorsException(String message) {
        super(message);
    }
}
